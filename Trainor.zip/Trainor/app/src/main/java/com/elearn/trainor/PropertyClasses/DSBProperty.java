package com.elearn.trainor.PropertyClasses;

public class DSBProperty {

    public String id;
    public String last_modified;
    public String name;
    public String release_date;
    public String imageURL;
    public String fileURL;
    public String file_size;
    public String order;
}
