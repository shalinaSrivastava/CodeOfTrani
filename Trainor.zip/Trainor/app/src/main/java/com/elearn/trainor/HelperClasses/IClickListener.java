package com.elearn.trainor.HelperClasses;

public interface IClickListener {
    public void onClick();
}
