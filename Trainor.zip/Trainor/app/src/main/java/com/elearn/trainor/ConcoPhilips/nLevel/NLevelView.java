package com.elearn.trainor.ConcoPhilips.nLevel;

/**
 * Created by sadra on 7/29/17.
 */


import android.view.View;

public interface NLevelView {

    public View getView(NLevelItem item);
}