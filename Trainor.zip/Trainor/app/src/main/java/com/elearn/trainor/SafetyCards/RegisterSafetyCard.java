package com.elearn.trainor.SafetyCards;

import com.google.firebase.perf.FirebasePerformance;
import com.google.firebase.perf.metrics.Trace;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.elearn.trainor.HelperClasses.WebServicesURL;
import com.elearn.trainor.DBHandler.DataBaseHandlerInsert;
import com.elearn.trainor.DBHandler.DataBaseHandlerSelect;
import com.elearn.trainor.HelperClasses.AlertDialogManager;
import com.elearn.trainor.HelperClasses.ConnectionDetector;
import com.elearn.trainor.HelperClasses.IClickListener;
import com.elearn.trainor.HelperClasses.SharedPreferenceManager;
import com.elearn.trainor.HelperClasses.VolleyErrorHandler;
import com.elearn.trainor.HomePage;
import com.elearn.trainor.PropertyClasses.SafetyCardProperty;
import com.elearn.trainor.R;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.HashMap;
import java.util.Map;

public class RegisterSafetyCard extends AppCompatActivity implements View.OnClickListener {
    LinearLayout ll_back, llhome;
    TextView text_header;
    EditText edt_card_no, edt_card_code;
    String alertMsgCardNo, alertMsgCardCode;
    ConnectionDetector connectionDetector;
    SharedPreferenceManager spManager;
    Button btn_add_card;
    DataBaseHandlerSelect dbSelect;
    DataBaseHandlerInsert dataBaseHandlerInsert;
    String dataBaseCardId;
    ProgressDialog pDialog;
    public boolean isActivityLive = false;
    FirebaseAnalytics analytics;
    Trace myTrace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_safety_card);
        isActivityLive = true;
        getControls();
    }

    public void getControls() {
        analytics = FirebaseAnalytics.getInstance(RegisterSafetyCard.this);
        myTrace = FirebasePerformance.getInstance().newTrace("Register_SafetyCard_trace");
        myTrace.start();

        dbSelect = new DataBaseHandlerSelect(RegisterSafetyCard.this);
        dataBaseHandlerInsert = new DataBaseHandlerInsert(RegisterSafetyCard.this);
        connectionDetector = new ConnectionDetector(RegisterSafetyCard.this);
        spManager = new SharedPreferenceManager(RegisterSafetyCard.this);
        alertMsgCardCode = getResources().getString(R.string.alertMsgCardCode);
        alertMsgCardNo = getResources().getString(R.string.alertMsgCardNo);
        ll_back = (LinearLayout) findViewById(R.id.ll_back);
        llhome = (LinearLayout) findViewById(R.id.llhome);
        text_header = (TextView) findViewById(R.id.text_header);
        text_header.setText(getString(R.string.register_saftey_cards));
        edt_card_no = (EditText) findViewById(R.id.edt_card_no);
        edt_card_code = (EditText) findViewById(R.id.edt_card_code);
        btn_add_card = (Button) findViewById(R.id.btn_add_card);
        SafetyCardProperty safetyCardProperty = new SafetyCardProperty();
        dataBaseCardId = safetyCardProperty.card_id;
        ll_back.setOnClickListener(this);
        llhome.setOnClickListener(this);
        btn_add_card.setOnClickListener(this);
        edt_card_no.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                Log.d("", "");
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.d("", "");
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().equals("")) {
                    if (s.toString().contains(" ")) {
                        String preValue = edt_card_no.getText().toString().substring(0, edt_card_no.getText().toString().indexOf(" "));
                        if (edt_card_no.getText().length() > 1) {
                            String postValue = edt_card_no.getText().toString().substring(edt_card_no.getText().toString().indexOf(" ") + 1, edt_card_no.getText().toString().length());
                            edt_card_no.setText(preValue + postValue);
                            edt_card_no.setSelection(preValue.length());
                        } else {
                            edt_card_no.setText(preValue);
                        }
                    }
                }
            }
        });
        edt_card_code.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                Log.d("", "");
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.d("", "");
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().equals("")) {
                    if (s.toString().contains(" ")) {
                        String preValue = edt_card_code.getText().toString().substring(0, edt_card_code.getText().toString().indexOf(" "));
                        if (edt_card_code.getText().length() > 1) {
                            String postValue = edt_card_code.getText().toString().substring(edt_card_code.getText().toString().indexOf(" ") + 1, edt_card_code.getText().toString().length());
                            edt_card_code.setText(preValue + postValue);
                            edt_card_code.setSelection(preValue.length());

                        } else {
                            edt_card_code.setText(preValue);
                        }
                    }
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_back:
                onBackPressed();
                break;
            case R.id.llhome:
                commonIntentMethod(HomePage.class);
                break;
            case R.id.btn_add_card:
                if (connectionDetector.isConnectingToInternet()) {
                    if (validateCredentials()) {
                        if (dbSelect.getSafetyCardAttribute(edt_card_no.getText().toString().trim()).size() > 0) {
                            AlertDialogManager.showDialog(RegisterSafetyCard.this, "", getResources().getString(R.string.card_no) + " " + edt_card_no.getText().toString().trim() + " " + getResources().getString(R.string.already_exists), false, null);
                        } else {
                            showWaitDialog();
                            addCards();
                        }
                    }
                } else {
                    AlertDialogManager.showDialog(RegisterSafetyCard.this, getResources().getString(R.string.internetErrorTitle), getResources().getString(R.string.internetErrorMessage), false, null);
                }
                break;
        }
    }

    public boolean validateCredentials() {
        if (edt_card_no.getText().toString().isEmpty()) {
            AlertDialogManager.showDialog(RegisterSafetyCard.this, "", alertMsgCardNo, false, null);
            return false;
        }
        if (edt_card_code.getText().toString().isEmpty()) {
            AlertDialogManager.showDialog(RegisterSafetyCard.this, "", alertMsgCardCode, false, null);
            return false;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        commonIntentMethod(SafetyCards.class);
    }

    public void addCards() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, WebServicesURL.Upcoming_SafetyCards_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    dismissWaitDialog();
                    AlertDialogManager.showDialog(RegisterSafetyCard.this, "", getResources().getString(R.string.card_added_successfully), false, new IClickListener() {
                        @Override
                        public void onClick() {
                            Bundle bundle = new Bundle();
                            bundle.putString("SafetyCardRegistered", "Yes");
                            analytics.logEvent("SafetyCardRegistered", bundle);

                            Intent intent = new Intent(RegisterSafetyCard.this, SafetyCards.class);
                            intent.putExtra("RegisterSafetyCard", "GetSafetyCards");
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            finish();
                            overridePendingTransition(R.anim.slide_from_right, R.anim.slide_to_left);
                        }
                    });
                } catch (Exception ex) {
                    Log.d("", ex.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissWaitDialog();
                String ErrorCode = VolleyErrorHandler.getErrorCode(error);
                if (ErrorCode.equals("401")) {
                    AlertDialogManager.showDialog(RegisterSafetyCard.this, getString(R.string.networkError), getString(R.string.internalServerError), false, null);
                } else if (ErrorCode.equals("404")) {
                    AlertDialogManager.showDialog(RegisterSafetyCard.this, getString(R.string.networkError), getString(R.string.internalServerError), false, null);
                } else if (ErrorCode.equals("500")) {
                    AlertDialogManager.showDialog(RegisterSafetyCard.this, getString(R.string.networkError), getString(R.string.internalServerError), false, null);
                } else if (ErrorCode.equals("Timeout Error")) {
                    AlertDialogManager.showDialog(RegisterSafetyCard.this, getString(R.string.networkError), getString(R.string.internalServerError), false, null);
                } else {
                    AlertDialogManager.showDialog(RegisterSafetyCard.this, getResources().getString(R.string.invalid_card_titile), getResources().getString(R.string.invalid_card_msg), false, null);
                }
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json");
                params.put("Accept", "application/json");
                params.put("Authorization", "Bearer " + spManager.getToken());
                return params;
            }

            @Override
            public byte[] getBody() throws AuthFailureError {
                String strParameters = "{\"cardId\":\"" + edt_card_no.getText() + "\",\"code\":\"" + edt_card_code.getText() + "\"}";
                return strParameters.getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        RequestQueue requestQueue11 = Volley.newRequestQueue(RegisterSafetyCard.this);
        requestQueue11.add(stringRequest);
    }

    public void commonIntentMethod(Class activity) {
        myTrace.stop();
        Intent intent = new Intent(RegisterSafetyCard.this, activity);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
        overridePendingTransition(R.anim.slide_from_left, R.anim.slide_to_right);
    }

    @Override
    protected void onStart() {
        isActivityLive = true;
        super.onStart();
    }

    @Override
    protected void onResume() {
        isActivityLive = true;
        super.onResume();
        analytics.setCurrentScreen(this, "RegisterSafetyCard", this.getClass().getSimpleName());
    }

    @Override
    protected void onStop() {
        myTrace.stop();
        isActivityLive = false;
        dismissWaitDialog();
        super.onStop();
    }

    public void showWaitDialog() {
        if (isActivityLive) {
            if (pDialog == null) {
                pDialog = new ProgressDialog(RegisterSafetyCard.this);
                pDialog.setMessage(getString(R.string.please_wait));
                pDialog.setCancelable(false);
                if (!pDialog.isShowing()) {
                    pDialog.show();
                }
            } else {
                if (!pDialog.isShowing()) {
                    pDialog.show();
                }
            }
        }
    }

    public void dismissWaitDialog() {
        if (pDialog != null && pDialog.isShowing()) {
            pDialog.dismiss();
        }
    }
}
