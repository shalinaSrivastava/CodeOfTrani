package com.elearn.trainor.PropertyClasses;

public class CustomerDetailsProperty {
    public String customer_id;
    public String customerName;
    public String workEmailAddress;
    public String departmentName;
    public String employeeNumber;
    public String title;
    public String workPhone;
    public String hasCopAccess;
}
