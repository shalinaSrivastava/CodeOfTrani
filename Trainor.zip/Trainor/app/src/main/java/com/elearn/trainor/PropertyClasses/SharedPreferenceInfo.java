package com.elearn.trainor.PropertyClasses;


public class SharedPreferenceInfo {
    public String UserID;
    public String Token;
    public String ProfilePicURL;
    public String FirstName;
    public String LastName;
    public String Email;
    public String dob;
    public String language;
    public String Phone_no;
    public String UserName;
}
