package com.elearn.trainor.PropertyClasses;

public class GetMoreCoursesProperty {
    public String course_id;
    public String uuid;
    public String language;
    public String internal_name;
    public String length;
    public String price;
    public String price_inc_vat;
    public String title;
    public String intro;
    public String goal;
    public String target_group;
    public String description;
    public boolean toBeSearched;
}
