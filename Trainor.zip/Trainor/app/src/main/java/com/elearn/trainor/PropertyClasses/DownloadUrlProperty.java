package com.elearn.trainor.PropertyClasses;

public class DownloadUrlProperty {
    public String licenseId;
    public String downloadURL;
    public String safetyCard_cardID;

}
