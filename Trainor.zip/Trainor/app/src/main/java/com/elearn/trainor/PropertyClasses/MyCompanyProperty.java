package com.elearn.trainor.PropertyClasses;

public class MyCompanyProperty {
    public String customerID;
    public String userID;
    public String MyCompanyId;
    public String name;
    public String lastModified;
    public String description;
    public String downloadUrl;
    public String fileName;
    public String fileSize;
    public String documentID;

    //for testing
    public String company_name;
    public String document_message_notification;
    public String locale; // new field 01-10-2019
}
