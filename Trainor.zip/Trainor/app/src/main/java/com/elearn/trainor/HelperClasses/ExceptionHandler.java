package com.elearn.trainor.HelperClasses;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.view.WindowManager;

public class ExceptionHandler {

    public static String getErrorMessage(Context context, Exception ex) {
        if (ex instanceof IllegalArgumentException) {
            return "Bad Format Type ";
        } else if (ex instanceof NumberFormatException) {
            return context.getResources().getString(android.support.design.R.string.abc_action_bar_home_description);
        } else if (ex instanceof NullPointerException) {
            return context.getResources().getString(android.support.design.R.string.abc_action_bar_home_description);
        } else if (ex instanceof WindowManager.BadTokenException) {
            return context.getResources().getString(android.support.design.R.string.abc_action_bar_home_description);
        } else if (ex instanceof ArrayIndexOutOfBoundsException) {
            return context.getResources().getString(android.support.design.R.string.abc_action_bar_home_description);
        } else if (ex instanceof IndexOutOfBoundsException) {
            return context.getResources().getString(android.support.design.R.string.abc_action_bar_home_description);
        } else if (ex instanceof ActivityNotFoundException) {
            return context.getResources().getString(android.support.design.R.string.abc_action_bar_home_description);
        }
        return "";
    }
}
