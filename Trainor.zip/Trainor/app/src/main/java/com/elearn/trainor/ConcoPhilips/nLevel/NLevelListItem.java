package com.elearn.trainor.ConcoPhilips.nLevel;

import android.view.View;

public interface NLevelListItem {

    public boolean isExpanded();
    public void toggle();
    public NLevelListItem getParent();
    public View getView();
}