package com.elearn.trainor.PropertyClasses;

/*public class NotificationProperty {
    public String notification_id;
    public String user_id;
    public String notification_category;
    public String notification_body;
}*/


public class NotificationProperty {
    public String notification_id;
    public String user_id;
    public String notification_category;
    public String notification_body;
    public String notification_type;
    public int notification_count;
    public String device_type;
    public String device_id;
}
