package com.elearn.trainor.PropertyClasses;

public class ToolsProperty {
    public String id;
    public String last_modified;
    public String name;
    public String force_download;
    public String language_code;
    public String background_color;
    public String is_landscape;
    public String customer_ids;
    public String iconURL;
    public String iconString;
    public String file;
    public String file_size;
    public String last_modified_From_DB;
}
