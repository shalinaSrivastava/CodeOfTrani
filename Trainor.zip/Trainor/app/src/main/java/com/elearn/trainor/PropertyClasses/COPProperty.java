package com.elearn.trainor.PropertyClasses;

public class COPProperty {
    public int cardID;
    public String userId;
    public String lisenceId;
    public String cardStatus;
    public String courseStatus;
    public String regdDate;
    public String placePlatformName;
    public String departmentName;
    public String placePlatformId;
    public String departmentId;
    public String topicDiscussed;
    public String riskIdentified;
    public String plannedFollowUp;
    public String heatColdStatus;
    public String pressureStatus;
    public String chemicalStatus;
    public String electricalStatus;
    public String gravityStatus;
    public String radiationStatus;
    public String noiseStatus;
    public String biologicalStatus;
    public String energyMovementStatus;
    public String presentMomentStatus;
}
