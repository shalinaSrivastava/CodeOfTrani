package com.elearn.trainor.PropertyClasses;

public class SCORMInfo {
    public String scormID;
    public String LicenceID;
    public String cmiLocation;
    public String cmiProgressMeasure;
    public String cmiCompletionStatus;
    public String cmiSuccessStatus;
    public String secretKey;
    public String identifier;
}
