package com.elearn.trainor.PropertyClasses;

public class SafetyCardProperty {

    public String valid_to;
    public String card_id;
    public String valid_from;
    public String company_name;
    public String approval_status;
    public String location_name;
    public String active_status;
    public String card_url;
    public String id;
    public String employeeId;
}
